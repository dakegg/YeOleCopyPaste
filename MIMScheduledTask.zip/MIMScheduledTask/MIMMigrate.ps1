﻿## Daily Delta Script
## 5/11/2016
##

$date = Get-Date -format M.d.yyyy
$a = Get-Date
$time = $a.ToShortTimeString()
$time = $time.replace(":","-")
$TranscriptPath = "E:\Logs\MIM01\" + "DeltaResults - " + $date + " " + $time + ".log"

# Switch to directory where script is located
pushd (split-path -parent $MyInvocation.MyCommand.Definition)

start-transcript -path $TranscriptPath

# ead.state.mn.us must always be the last connector in the array below
$arrForests = @()
$arrForests = "co.dhs","ad.dot.state.mn.us","mndoc.local","mdh-ad.health.state.mn.us","mndnr.dnr.state.mn.us","admin.state.mn.us","mndeeddom.deed.state.mn.us","dps.state.mn.us","mdva.state.mn.us","hlb.state.mn.us","mrad.mdor.state.mn.us","pca.state.mn.us","finance.state.mn.us","mda.state.mn.us","commerce-nt1.com","mhfa.state.mn.us","educ.state.mn.us","dli.local","oah.state.mn.us","ossdomain.mn","mnzoo.int","pmd.admin.state.mn.us","heso.state.mn.us","mnbah.internal","irr.local","dhr.state.mn.us","cfboard.mn","omhdd.com","state.mn.gov","ead.state.mn.us"
$sourceForest = "admin.state.mn.us"
$targetForest = "state.mn.gov"

. .\MIMFunctions.ps1
. .\Execute-Runprofile.ps1

## Capture the migration state for users
Execute-RunProfile 'ead.state.mn.us' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'ead.state.mn.us' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

## Export Migration state to MIM
Execute-RunProfile 'MIM Management Agent' 'Export'
Get-Job | Wait-Job | Receive-Job
Start-Sleep -Seconds 15
Execute-RunProfile 'MIM Management Agent' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'MIM Management Agent' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

##Import Source and Target forests
Execute-RunProfile $sourceForest 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile $targetForest 'Delta Import'
Get-Job | Wait-Job | Receive-Job

##Sync Source and Target forests
Execute-RunProfile $sourceForest 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile $targetForest 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

##Export to MIM
Execute-RunProfile 'MIM Management Agent' 'Export'
Get-Job | Wait-Job | Receive-Job
Start-Sleep -Seconds 15
Execute-RunProfile 'MIM Management Agent' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'MIM Management Agent' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

## Update EAD with target forest information
Execute-RunProfile 'ead.state.mn.us' 'Export'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'ead.state.mn.us' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'ead.state.mn.us' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

#run this to re-connect the migrated account.  Should result in no exports to WP
Execute-RunProfile 'WHITEPAGES' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

Get-Job | Remove-Job

Stop-Transcript

