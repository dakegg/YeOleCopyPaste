## AADConnect Run History Purge
## run with an inline switch of X days to purge
## 5/11/2016

$date = Get-Date -format M.d.yyyy
$a = Get-Date
$time = $a.ToShortTimeString()
$time = $time.replace(":","-")
$TranscriptPath = "E:\Logs\MIM01\" + "RunHistoryPurgeResults - " + $date + " " + $time + ".log"

#$DeleteDay = Get-Date

#$DayDiff = New-Object System.TimeSpan 1, 0, 0, 0, 0
#$DeleteDay = $DeleteDay.Subtract($DayDiff)
$DeleteDay = (Get-Date).AddDays(-7)

start-transcript -path $TranscriptPath

Write-Host "Deleting run history earlier than:" $DeleteDay.toString('MM/dd/yyyy')

$lstSrv = @(get-wmiobject -class "MIIS_SERVER" -namespace "root\MicrosoftIdentityIntegrationServer" -computer ".") 

Write-Host "Result: " $lstSrv[0].ClearRuns($DeleteDay.toString('yyyy-MM-dd')).ReturnValue

Trap 
{ 
Write-Host "`nError: $($_.Exception.Message)`n" -foregroundcolor white -backgroundcolor darkred
Exit
}

stop-transcript