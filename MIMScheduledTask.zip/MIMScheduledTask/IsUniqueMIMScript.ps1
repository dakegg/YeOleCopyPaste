[CmdletBinding(SupportsShouldProcess = $True)]
param
(
	[Parameter(Mandatory = $false, HelpMessage = "Creates 'scheduled task' in Windows Scheduler that can be adjusted in the future to perform synchronization cycle(s) at particular time interval")]
	[Switch]$Schedule,
	[switch]$interactive = $false
)

# Switch to directory where script is located
Push-Location (split-path -parent $MyInvocation.MyCommand.Definition)

if ($schedule)
{
	# If scheduled tasks needs to be recreated, run: "./IsUniqueMIMScript.ps1 -schedule"
	$taskname = "isUnique Hourly Script"
	schtasks.exe /create /RL HIGHEST /NP /sc MINUTE /MO 60 /st 05:45 /et 20:45 /tn "$taskname" /tr "$PSHOME\powershell.exe -c '. ''$($myinvocation.mycommand.definition)'''"
	exit
}
Write-Host "Starting IsUnique Process..."
Function Write-Status
{
	$ActivityMessage = "Processing Object, Please wait..."
	$StatusMessage = ("Processing {0} of {1}: {2}" -f $count, @($sqloutput).count, $sqluser.object_id)
	$PercentComplete = ($count / @($sqloutput).count * 100)
	Write-Progress -Activity $ActivityMessage -Status $StatusMessage -PercentComplete $PercentComplete
	$count ++
}

# Get MIISAutomation and RMA lithnet modules loaded if they aren't

if (Get-Module -ListAvailable -Name "LithnetMiisAutomation") { Install-Module LithnetMiisAutomation } else { Write-Host "LithnetMiisAutomation Module is not installed." ; Exit}

if (Get-Module -ListAvailable -Name "LithnetRMA") { Install-Module LithnetRMA } else { Write-Host "LithnetRMA Module is not installed." ; Exit}
Set-ResourceManagementClient -BaseAddress http://mimportal.ead.state.mn.us:5725

# get list of users who have something other than unique or cloud in carlicense
$SQLOutput = $null
$SQLOutput = Invoke-Sqlcmd -Query "SELECT [object_id],[attribute_name],[string_value_indexable] FROM [FIMSynchronizationService].[dbo].[mms_metaverse_multivalue] WHERE attribute_name = 'carLicense' and string_value_indexable not like 'unique%' and string_value_indexable not like 'cloud'" -ServerInstance "MIM_Prod_AG2.ead.state.mn.us\SQMIMPRD"
Write-Host "Found $($SQLOutput.count) objects in the metaverse to check."
#foreach we check w\ object ID using get-mvobject -id xxxxxxx
$NotUniques = @()

$count = 1
foreach ($sqluser in $sqloutput)
{
	$testuser = $null
	$testuser = Get-MVObject -ID $sqluser.object_id
	if ($testuser.attributes.carlicense.values.value -notcontains "unique")
	{
		$NotUniques += $testuser		
	}
	if($interactive) { Write-Status; $count++ }
}

#$NotUniques = $null

#$NotUniques = Get-MVObject -ObjectType Person | Where-object { ($_.attributes.carlicense.values.value -notcontains "unique") }

if ($NotUniques)
{
	if ($interactive) {Write-Host "Found $($NotUniques.count) objects without UNIQUE stamped in CarLicense in Metaverse"}
	Foreach ($NotUnique in $NotUniques)
	{
		# Get the MAIL attribute of the object in question
		[boolean]$skipUPN = $false
        $Mail = $null
		$Mail = $NotUnique.attributes.mail.values.value

		if (!$mail)
        {
            $skipUPN = $True
            Write-Host "Mail not populated, this user is UNLICENSED, using UPN for Uniqueness check instead"
            $mail = $NotUnique.attributes.userPrincipalName.values.value
        }


		Write-Host "Checking $Mail - $($NotUnique.Attributes.csObjectID.Values.value)"

		# Create a new MV query (which will query both Person and CloudPerson objects)
		$query = New-MVQuery -Attribute mail -Operator Equals -Value $mail

		# Query the MV
		$Conflicts = $null
        $Conflicts = Get-MVObject -Queries $query -ObjectType person

		# If there's a match, that's bad, we must set as Conflict in Portal
		if ($Conflicts.Count -gt 1)
		{
			if ($interactive) {Write-Host "Found more than 1 object with that value, so it would be stamped as conflict."}
			# use Lithnet RMA to clear carlicense and set the value of carlicense to Conflict
			$ConflictObject = Get-Resource -ID $NotUnique.Attributes.csObjectID.Values.value
			$ConflictObject.CarLicense = "conflict"
			Save-Resource $ConflictObject
		}
		Else
		{
			# use LithnetRMA to clear carlicense and set the value of carlicense to Unique
			# use LithnetRMA to stamp UPN

			if ($interactive) {Write-Host "Only found 1 object with that value, so it's unique."}

			$UniqueObject = $null
			$UniqueObject = Get-Resource -ID $NotUnique.Attributes.csObjectID.Values.value
			$UniqueObject.CarLicense = "unique"
			if (!$skipUPN) {$UniqueObject.userPrincipalName = $UniqueObject.email}
			Save-Resource $UniqueObject
		}
	}
}
else 
{
	if ($interactive) {Write-Host "Found ZERO objects without UNIQUE stamped in CarLicense in Metaverse"}	
}


# from here, regular sync cycle should pickup change in portal and stage export to AD of the carLicense value

# value of Unique will allow it thru AAD Connect 