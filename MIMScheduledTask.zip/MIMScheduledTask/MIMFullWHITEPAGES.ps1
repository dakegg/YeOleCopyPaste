﻿## Daily Full Script
## 5/11/2016
##

$date = Get-Date -format M.d.yyyy
$a = Get-Date
$time = $a.ToShortTimeString()
$time = $time.replace(":","-")
$TranscriptPath = "E:\Logs\MIM01\" + "FullWHITEPAGESResults - " + $date + " " + $time + ".log"

# Switch to directory where script is located
pushd (split-path -parent $MyInvocation.MyCommand.Definition)

start-transcript -path $TranscriptPath

. .\Execute-Runprofile.ps1

# Adding this as a one-time full sync for SQL PTOD capture - 6/22/2021
#Execute-RunProfile 'MIM Management Agent' 'Full Import'
#Get-Job | Wait-Job | Receive-Job
#Execute-RunProfile 'MIM Management Agent' 'Full Synchronization'
#Get-Job | Wait-Job | Receive-Job

Execute-RunProfile 'WHITEPAGES' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'WHITEPAGES' 'Full Synchronization'
Get-Job | Wait-Job | Receive-Job

Execute-RunProfile 'PeopleData' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'PeopleData' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

Execute-RunProfile 'MIM Management Agent' 'Export'
Get-Job | Wait-Job | Receive-Job
Start-Sleep -Seconds 60
Execute-RunProfile 'MIM Management Agent' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'MIM Management Agent' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job
<#Execute-RunProfile 'MIM Management Agent' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'MIM Management Agent' 'Full Synchronization'
Get-Job | Wait-Job | Receive-Job#>

Execute-RunProfile 'RemedyData' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'RemedyData' 'Full Synchronization'
Get-Job | Wait-Job | Receive-Job

Get-Job | Remove-Job

Stop-Transcript
