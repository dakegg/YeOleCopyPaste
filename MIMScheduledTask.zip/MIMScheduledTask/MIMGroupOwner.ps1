﻿## Daily Full Script
## 5/11/2016
##

$date = Get-Date -format M.d.yyyy
$a = Get-Date
$time = $a.ToShortTimeString()
$time = $time.replace(":","-")
$TranscriptPath = "E:\Logs\MIM01\" + "GroupOwnerResults - " + $date + " " + $time + ".log"

# Switch to directory where script is located
pushd (split-path -parent $MyInvocation.MyCommand.Definition)

start-transcript -path $TranscriptPath

. .\Execute-Runprofile.ps1

Execute-RunProfile 'Group Owner' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'Group Owner' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

Get-Job | Remove-Job

Stop-Transcript
