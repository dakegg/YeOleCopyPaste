﻿## Daily Full Script
## 5/11/2016
##

$date = Get-Date -format M.d.yyyy
$a = Get-Date
$time = $a.ToShortTimeString()
$time = $time.replace(":","-")
$TranscriptPath = "E:\Logs\MIM01\" + "FullResults - " + $date + " " + $time + ".log"

# Switch to directory where script is located
pushd (split-path -parent $MyInvocation.MyCommand.Definition)

start-transcript -path $TranscriptPath

# ead.state.mn.us must always be the last connector in the array below
$arrForests = @()
$arrForests = "co.dhs","ad.dot.state.mn.us","mndoc.local","mdh-ad.health.state.mn.us","mndnr.dnr.state.mn.us","admin.state.mn.us","mndeeddom.deed.state.mn.us","dps.state.mn.us","mdva.state.mn.us","hlb.state.mn.us","mrad.mdor.state.mn.us","pca.state.mn.us","finance.state.mn.us","mda.state.mn.us","commerce-nt1.com","mhfa.state.mn.us","educ.state.mn.us","dli.local","oah.state.mn.us","ossdomain.mn","mnzoo.int","pmd.admin.state.mn.us","heso.state.mn.us","mnbah.internal","irr.local","dhr.state.mn.us","cfboard.mn","state.mn.gov","ead.state.mn.us"

. .\MIM01Functions.ps1
. .\Execute-Runprofile.ps1

ParallelFullImport
SerialFullSync

Execute-RunProfile 'WHITEPAGES' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'WHITEPAGES' 'Full Synchronization'
Get-Job | Wait-Job | Receive-Job

Execute-RunProfile 'mn365Graph' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'mn365Graph' 'Full Synchronization'
Get-Job | Wait-Job | Receive-Job

Execute-RunProfile 'SEMA4' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'SEMA4' 'Full Synchronization'
Get-Job | Wait-Job | Receive-Job

Execute-RunProfile 'MIM Management Agent' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'MIM Management Agent' 'Full Synchronization'
Get-Job | Wait-Job | Receive-Job

Execute-RunProfile 'RemedyData' 'Full Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'RemedyData' 'Full Synchronization'
Get-Job | Wait-Job | Receive-Job

Stop-Transcript
