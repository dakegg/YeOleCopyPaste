## MIM01 Sync Functions
## 5/12/2016
## Thread count is the number of imports/exports to do at once

Function SerialDeltaSync
	{
	. .\Execute-Runprofile.ps1
	
		Foreach ($forest in $arrForests)
		{
		Execute-RunProfile $forest 'Delta Sync'
		Get-Job | Wait-Job | Receive-Job
		}
	}
	
Function SerialFullSync
	{
	. .\Execute-Runprofile.ps1
	
		Foreach ($forest in $arrForests)
		{
		Execute-RunProfile $forest 'Full Sync'
		Get-Job | Wait-Job | Receive-Job
		}
	}
	
function ParallelDeltaImport
	{  
	. .\Execute-Runprofile.ps1
			$ThreadCount = 6

			$ubound = $ThreadCount

			For($lbound = 0 ; $lbound -lt $arrForests.Count ; $ThreadCount)
				{
				$currentforests = $arrForests[($lbound)..($ubound -1)]		
				Foreach($forest in $currentforests)
					{
						Write-Host "Launching " $forest		
						Execute-RunProfile $forest 'Delta Import'
					}
				Write-Host "Wait to finish the batch"
				Get-Job | Wait-Job | Receive-Job
				$currentforests = $null
				$lbound = $lbound  + $ThreadCount
				$ubound = $ubound + $ThreadCount
				}
			$lbound = $null
			$ubound = $null
			$currentbatch = $null
			$forest = $null
	}
	
function ParallelFullImport
	{  
	. .\Execute-Runprofile.ps1
			$ThreadCount = 6

			$ubound = $ThreadCount

			For($lbound = 0 ; $lbound -lt $arrForests.Count ; $ThreadCount)
				{
				$currentforests = $arrForests[($lbound)..($ubound -1)]		
				Foreach($forest in $currentforests)
					{
						Write-Host "Launching " $forest		
						Execute-RunProfile $forest 'Full Import'
					}
				Write-Host "Wait to finish the batch"
				Get-Job | Wait-Job | Receive-Job
				$currentforests = $null
				$lbound = $lbound  + $ThreadCount
				$ubound = $ubound + $ThreadCount
				}
			$lbound = $null
			$ubound = $null
			$currentbatch = $null
			$forest = $null
	}

function ParallelExport
	{  
	. .\Execute-Runprofile.ps1
			$ThreadCount = 6

			$ubound = $ThreadCount

			For($lbound = 0 ; $lbound -lt $arrForests.Count ; $ThreadCount)
				{
				$currentforests = $arrForests[($lbound)..($ubound -1)]		
				Foreach($forest in $currentforests)
					{
						Write-Host "Launching " $forest		
						Execute-RunProfile $forest 'Export'
					}
				Write-Host "Wait to finish the batch"
				Get-Job | Wait-Job | Receive-Job
				$currentforests = $null
				$lbound = $lbound  + $ThreadCount
				$ubound = $ubound + $ThreadCount
				}
			$lbound = $null
			$ubound = $null
			$currentbatch = $null
			$forest = $null
	}