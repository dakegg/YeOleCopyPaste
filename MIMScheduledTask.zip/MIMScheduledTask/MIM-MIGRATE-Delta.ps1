﻿## Migration Delta Script
## 3/26/2024
##

$date = Get-Date -format M.d.yyyy
$a = Get-Date
$time = $a.ToShortTimeString()
$time = $time.replace(":","-")
$TranscriptPath = "E:\Logs\MIM01\Migrations\" + "MigrationDeltaResults - " + $date + " " + $time + ".log"

# Switch to directory where script is located
pushd (split-path -parent $MyInvocation.MyCommand.Definition)

start-transcript -path $TranscriptPath

. .\MIM01Functions.ps1
. .\Execute-Runprofile.ps1

## Import users for MIGRATE
Execute-RunProfile 'ead.state.mn.us' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'ead.state.mn.us' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

## Export to MIM
Execute-RunProfile 'MIM Management Agent' 'Export'
Get-Job | Wait-Job | Receive-Job
Start-Sleep -Seconds 60
Execute-RunProfile 'MIM Management Agent' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'MIM Management Agent' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

## Import and sync users from agency AD
Execute-RunProfile 'co.dhs' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'dps.state.mn.us' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'dps.state.mn.us' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'co.dhs' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

## Migrate users in EAD
Execute-RunProfile 'ead.state.mn.us' 'Export'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'ead.state.mn.us' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'ead.state.mn.us' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

## Write Display Name to Portal on migrated user
Execute-RunProfile 'MIM Management Agent' 'Export'
Get-Job | Wait-Job | Receive-Job
Start-Sleep -Seconds 60
Execute-RunProfile 'MIM Management Agent' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'MIM Management Agent' 'Delta Synchronization'
Get-Job | Wait-Job | Receive-Job

Get-Job | Remove-Job

Stop-Transcript