## Log File Purge
## 5/11/2016
##

$date = Get-Date -format M.d.yyyy
$a = Get-Date
$time = $a.ToShortTimeString()
$time = $time.replace(":","-")
$TranscriptPath = "E:\Logs\" + "LogPurgeResults - " + $date + " " + $time + ".log"

$limit = (Get-Date).AddDays(-28)
$psmapath = "E:\Logs\PSMALogs"
$aadconnectpath = "E:\Logs\AADConnect"

# Delete files older than the $limit.
Get-ChildItem -Path $psmapath -Recurse -Filter *.log | Where-Object { !$_.PSIsContainer -and $_.LastWriteTime -lt $limit } | Remove-Item -Force -Recurse
Get-ChildItem -Path $aadconnectpath -Recurse -Filter *.log | Where-Object { !$_.PSIsContainer -and $_.LastWriteTime -lt $limit } | Remove-Item -Force -Recurse
