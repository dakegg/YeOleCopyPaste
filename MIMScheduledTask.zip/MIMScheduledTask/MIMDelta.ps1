﻿## Daily Delta Script
## 5/11/2016
##

$date = Get-Date -format M.d.yyyy
$a = Get-Date
$time = $a.ToShortTimeString()
$time = $time.replace(":","-")
$TranscriptPath = "D:\Logs\MIM\" + "DeltaResults - " + $date + " " + $time + ".log"

# Switch to directory where script is located
pushd (split-path -parent $MyInvocation.MyCommand.Definition)

start-transcript -path $TranscriptPath

# EADLAB must always be the last connector in the array below
$arrForests = @()
$arrForests = "GREEN" #3"ad.dot.state.mn.us","admin.state.mn.us","cfboard.mn","commerce-nt1.com","dhr.state.mn.us","dli.local","dps.state.mn.us","educ.state.mn.us","finance.state.mn.us","heso.state.mn.us","hlb.state.mn.us","mda.state.mn.us","mdh-ad.health.state.mn.us","mdva.state.mn.us","mnbah.internal","mndeeddom.deed.state.mn.us","mndnr.dnr.state.mn.us","mnzoo.int","mrad.mdor.state.mn.us","oah.state.mn.us","pca.state.mn.us","pmd.admin.state.mn.us","state.mn.gov" #,"mhfa.state.mn.us","ossdomain.mn","irr.local"

. .\MIMFunctions.ps1
. .\Execute-Runprofile.ps1

Execute-RunProfile 'PORTAL' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'PORTAL' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job

Execute-RunProfile 'EADLAB' 'Export'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'EADLAB' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'EADLAB' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job

ParallelDeltaImport
SerialDeltaSync

## GraphAPI Connector
<#Execute-RunProfile 'mn365Graph' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'mn365Graph' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job#>

## SEMA4 Connector
<#Execute-RunProfile 'SEMA4' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'SEMA4' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job#>

## RemedyData Check
<#Execute-RunProfile 'RemedyData' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job#>

## Whitepages
<#Execute-RunProfile 'WHITEPAGES' 'Export'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'WHITEPAGES' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'WHITEPAGES' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job#>

## Staged User
Execute-RunProfile 'PORTAL' 'Export'
Get-Job | Wait-Job | Receive-Job

## Second sync for deprovision user to EAD
<#Execute-RunProfile 'EADLAB' 'Export'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'EADLAB' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'EADLAB' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job#>

## Write Display Name to Portal on new user
<#Execute-RunProfile 'PORTAL' 'Export'
Get-Job | Wait-Job | Receive-Job
Start-Sleep -Seconds 60
Execute-RunProfile 'PORTAL' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'PORTAL' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job#>

## RemedyData Updates
<#Execute-RunProfile 'RemedyData' 'Export'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'RemedyData' 'Delta Import'
Get-Job | Wait-Job | Receive-Job
Execute-RunProfile 'RemedyData' 'Delta Sync'
Get-Job | Wait-Job | Receive-Job#>

#ParallelExport

Stop-Transcript

